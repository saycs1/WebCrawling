# -*- coding: utf-8 -*-
import scrapy
import pymongo


class ToScrapeSpiderXPath(scrapy.Spider):
    name = 'toscrape-xpath'
    start_urls = [
        'http://quotes.toscrape.com/',
    ]

    def parse(self, response):
        for quote in response.xpath('//div[@class="quote"]'):
            
            yield {
                'text': quote.xpath('./span[@class="text"]/text()').extract_first(),
                'author': quote.xpath('.//small[@class="author"]/text()').extract_first(),
                'tags': quote.xpath('.//div[@class="tags"]/a[@class="tag"]/text()').extract()
            }

        next_page_url = response.xpath('//li[@class="next"]/a/@href').extract_first()
        if next_page_url is not None:
            yield scrapy.Request(response.urljoin(next_page_url))

        yield self.about_url

    def about_url(self, response):
        for quote in response.xpath('//div[@class="quote"]'):
            request = scrapy.Request(quote.xpath('//span/a/@href').extract()[0],
                                     callback=self.parse2)
            print('*' * 100)
            print(quote.xpath('//span/a/@href').extract()[0])
            yield request

#author 링크내 정보 추가
    def parse2(self, response):
        db2 = week6.pipelines.MongoDBPipeline.db
        item = Week6Item()
        item['Name'] = response.xpath('/html/body/div/div[2]/h3/text()').extract()
        item['Born'] = response.xpath('/html/body/div/div[2]/p[1]/span[1]/text()').extract()
        item['Description'] = response.xpath('/html/body/div/div[2]/div/text()').extract()

        db2.Quotes.update({"author" : { "name" : item["Name"] , "born" : item["Born"] , "description" : item["Description"] }})          

        yield item
