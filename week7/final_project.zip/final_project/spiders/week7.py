# -*- coding: utf-8 -*-
import scrapy

class ScrapyKBO(scrapy.Spider):
    name = 'scrapy_KBO;'
    start_urls = [
        'https://www.koreabaseball.com/Game/LiveText.aspx?leagueId=1&seriesId=0&gameId=20180912KTSK0&gyear=2018/',
        ]

    def parse(self, response):
        for KBO in response.xpath('//div[@id="numCont11"]'):
            yield {
                'Pitcher': KBO.xpath('').extract(),
                'Batter' : KBO.xpath('').extract(),
                'Runner' : KBO.xpath('').extract(),
                'Pitchcall' : KBO.xpath('').extract()
                }
            
