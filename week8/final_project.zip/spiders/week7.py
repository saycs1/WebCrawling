# -*- coding: utf-8 -*-
import scrapy
import re

class ScrapyKBO(scrapy.Spider):
    name = 'scrapy_KBO'
    start_urls = [
        'https://www.koreabaseball.com/Game/LiveTextView2.aspx?leagueId=1&seriesId=0&gameId=20180912KTSK0&gyear=2018',
        ]

    def parse(self, response):
        for KBO in response.xpath('//div[@class="numCon"]'):
            kbo_all = KBO.xpath('./span/text()').extract()
            yield {
                'kbo_all2': kbo_all  
                }
        yield self.export

    def export(self, repsonse):
        for kbo_one in kbo_all2:
            pitch = re.findall('[-]\s[0-9]+', kbo_one)
            playresult = re.findall('[\s+[가-힣]+',kbo_one)

            yield {
                'pitch': pitch,
                'playresult':playresult
                }
                

            
